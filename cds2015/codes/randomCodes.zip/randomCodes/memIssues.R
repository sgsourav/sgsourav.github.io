# Check what packages are loaded into memory
search()

# Check the variables in memory
ls()

# Library "pryr" helps understand memory allocation
library("pryr")
object_size(g)


# Find the size of common objects
object_size(numeric())
object_size(logical())
object_size(list())
object_size(data.frame())

# Check if the memory allocation is linear
sizes <- sapply(0:50, function(n) object_size(seq_len(n)))
plot(0:50, sizes - 40, xlab = "Length", 
     ylab = "Bytes excluding overhead", type = "n")
abline(h = 0, col = "grey80")
abline(h = c(8, 16, 32, 48, 64, 128), col = "grey80")
abline(a = 0, b = 4, col = "grey90", lwd = 4)
lines(sizes - 40, type = "s")

# Check how copying works
x <- 1:1e6
object_size(x)
y <- list(x, x, x)
object_size(y)
object_size(x, y)

a <- 1:1e6
b <- list(1:1e6, 1:1e6, 1:1e6)
object_size(a)
object_size(b)
object_size(a, b)

object_size("banana")
object_size(rep("banana", 10))

# Check total memory used
mem_used()

# Check how much memory required
mem_change(x <- 1:1e6)

# Check how much memory saved
mem_change(x <- 1:1e6)
mem_change(rm(x))
