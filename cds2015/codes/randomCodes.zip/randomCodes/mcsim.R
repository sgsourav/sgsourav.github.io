# Integration under the normal curve
runs <- 1000000
sims <- rnorm(runs, mean = 1, sd = 10)
mc.integral <- sum(sims >= 3 & sims <= 6)/runs
mc.integral

# Approximating the Binomial Distribution
runs <- 1000000
one.trial <- function(){
  tosses <- sample(c(0,1), 10, replace=T)
  sum(tosses) > 3
}
mc.binom <- sum(replicate(runs,one.trial()))/runs
mc.binom

# Approximating Pi
runs <- 1000000
xs <- runif(runs, min=-0.5, max=0.5)
ys <- runif(runs, min=-0.5, max=0.5)
in.circle <- (xs^2 + ys^2 <= 0.5^2)
mc.pi <- (sum(in.circle)/runs) * 4
plot(xs, ys, pch='.', col=ifelse(in.circle,"blue","grey"),
     xlab='', ylab='', asp=1,
     main = paste("MC Approximation of Pi =",mc.pi))

# Finding p-Values
runs <- 100000
a.samples <- rbeta(runs, 20, 100)
b.samples <- rbeta(runs, 38, 110)
mc.p.value <- sum(a.samples > b.samples)/runs
hist(b.samples/a.samples)

# Game of Luck
runs <- 100000
play.game <- function(){
  results <- sample(c(1,1,-1,2), 10, replace=T)
  return(sum(results) < 7.5)
}
mc.prob <- sum(replicate(runs,play.game()))/runs
mc.prob

# Stock market
days <- 200
changes <- rnorm(200, mean=1.001, sd=0.005)
plot(cumprod(c(20,changes)), type='l',
     ylab="Price", xlab="day", 
     main="BAYZ closing price (sample path)")

runs <- 100000
generate.path <- function(){
  days <- 200
  changes <- rnorm(200, mean=1.001, sd=0.005)
  sample.path <- cumprod(c(20,changes))
  closing.price <- sample.path[days+1]
  return(closing.price)
}
mc.closing <- replicate(runs,generate.path())

summary(mc.closing)
quantile(mc.closing,0.95)
quantile(mc.closing,0.05)
