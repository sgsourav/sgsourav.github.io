#include <stdio.h>

int strLen (char *str) {
  int count;
  for (count = 0; *str != '\0'; str++)
    count++;
  return count;
}

int strCmp (char *str1, char *str2) {
  for ( ; *str1 == *str2; str1++, str2++)
    if (*str1 == '\0')
      return 0;
  return *str1 - *str2;
}

void strCpy (char *dest, char *src) {
  while ((*dest++ = *src++))
    ;
}

int main() {
  int i, pLen, sLen;
  char *ptrArray[] = {"Sourav", "Sounak", "Rishi", "Ritchie"};
  char strArray[][10] = {"Sourav", "Sounak", "Rishi", "Ritchie"};

  printf("Assignment complete!\n");

  pLen = (sizeof(ptrArray) / sizeof(ptrArray[0]));
  sLen = (sizeof(strArray) / sizeof(strArray[0]));

  printf("\n------------- ptrArray -------------\n");
  for (i = 0; i < pLen; i++)
    printf("ptrArray[%d] = %s\t Length = %d\n", i, ptrArray[i], strLen(ptrArray[i]));

  printf("\n------------- strArray -------------\n");
  for (i = 0; i < sLen; i++)
    printf("strArray[%d] = %s\t Length = %d\n", i, strArray[i], strLen(strArray[i]));

  printf("\n------------- sizeof() -------------\n");
  printf("Size of ptrArray = %ld\n", sizeof(ptrArray));
  printf("Size of strArray = %ld\n", sizeof(strArray));

  printf("\n------------- modify() -------------\n");
  strArray[0][1] = 'a';
  printf("strArray[0] = %s\t Length = %d\n", strArray[0], strLen(strArray[0]));
  strCpy(strArray[1], "Sushmita");
  printf("strArray[1] = %s\t Length = %d\n", strArray[1], strLen(strArray[1]));

  ptrArray[0][1] = 'a';
  printf("ptrArray[0] = %s\t Length = %d\n", ptrArray[0], strLen(ptrArray[0]));
  strCpy(ptrArray[1], "Sushmita");
  printf("ptrArray[1] = %s\t Length = %d\n", ptrArray[1], strLen(ptrArray[1]));

  return 0;
}
