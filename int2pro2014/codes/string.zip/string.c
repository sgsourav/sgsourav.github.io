#include <stdio.h>

int strLen (char *str) {
  int count;
  for (count = 0; *str != '\0'; str++)
    count++;
  return count;
}

int strCmp (char *str1, char *str2) {
  for ( ; *str1 == *str2; str1++, str2++)
    if (*str1 == '\0')
      return 0;
  return *str1 - *str2;
}

void strCpy (char *dest, char *src) {
  while ((*dest++ = *src++))
    ;
}

int main() {
  char *oneString = "Sourav", *twoString = "Sounak";
  char firString[] = "Sourav", secString[] = "Sounak";
  
  printf("Assignment complete!\n");

  printf("String One = %s\t Length = %d\n", oneString, strLen(oneString));
  printf("String Two = %s\t Length = %d\n", twoString, strLen(twoString));
  printf("Comparison = %d\n", strCmp(oneString, twoString));

  printf("String One = %s\t Length = %d\n", firString, strLen(firString));
  printf("String Two = %s\t Length = %d\n", secString, strLen(secString));
  printf("Comparison = %d\n", strCmp(firString, secString));

  return 0;
}
