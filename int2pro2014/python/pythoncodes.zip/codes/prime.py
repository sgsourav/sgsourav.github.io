def isPrime (n):
    return len(filter(lambda x : n%x == 0, range(2,n)))

def isPrimeLC (n):
    return (True not in [n%x == 0 for x in range(2,n)])

def isPrimeLazy (n):
    return (True not in [n%x == 0 for x in xrange(2,n)])

def isPrimeLast (n):
    return (not any(n%x == 0 for x in xrange(2,n))
