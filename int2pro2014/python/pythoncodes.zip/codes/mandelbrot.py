from Tkinter import *

def inMandelSet(c, iteration = 20, threshold = 2):
    z = 0
    for h in range(0, iteration):
        z = z**2 + c
        if abs(z) >= threshold:
            return False
    
    return True

root = Tk()
w = Canvas(root, width=600, height=600)
w.pack()

print "Initializing..."

for x in range(0,600):
    for y in range(0,600):
        c = complex(x / 200.0 - 2.0, y / 200.0 - 1.5)
        if inMandelSet(c, 20, 2):
            w.create_line(x, 600-y, x+1, 601-y, fill="black")
            w.pack()

print "Complete!"

root.mainloop()
