# complete read
f = open('testfile.txt', 'r')
contents = f.read()
print contents
f.close()

# line by line read
f = open('testfile.txt', 'r')
for i, line in enumerate(f):
    print '(Line #' + str(i + 1) + ') ' + line
f.close()

# make dictionary
f = open('testfile.txt', 'r')
exam_dates = {}
for line in f:
    split_line = line.split(':')
    subject = split_line[0]
    subject = subject.strip()
    date = split_line[1]
    date = date.strip()
    exam_dates[subject] = date

f.close()
print exam_dates

# with with
with open('testfile.txt','r') as f:
    for line in f:
        exam_dates[line.split(':')[0].strip()] = line.split(':')[1].strip()

print exam_dates

# one line code
exam_dates =  dict([(line.split(':')[0].strip(), line.split(':')[1].strip()) \
                        for line in open('testfile.txt','r')])
print exam_dates
