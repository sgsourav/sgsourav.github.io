def isPositive (x):
    return x > 0

lst = [-1, 2, -3, 4, -5, 6]
print "the list :", lst
print "normal filter :",
print filter(isPositive, lst)

print "lambda filter :",
print filter(lambda x : x < 0, lst)


def square (x):
    return x*x

print "normal map :",
print map(square, lst)

print "lambda map :",
print map(lambda x : x*x + 1, lst)


def add (x, y):
    return x + y

print "normal reduce :",
print reduce(add, lst)

print "lambda reduce :",
print reduce(lambda x, y : x + y + 1, lst)


def naiveDot (a, b):
    dot = 0
    for i in range(len(a)):
        dot += a[i]*b[i]
    return dot

def compreDot (a, b):
    prodlist = [a[i] * b[i] for i in range(len(a))]
    return reduce(add, prodlist)

def sumDot (a, b):
    return sum(a[i] * b[i] for i in range(len(a)))

def tupleDot (a, b):
    return sum(x * y for (x, y) in zip(a, b))

lstA = [1, 2, 3, 4, 5]
lstB = [5, 4, 3, 2, 1]

print "naive dot product :",
print naiveDot (lstA, lstB)

print "reduce dot product :",
print compreDot (lstA, lstB)

print "sum dot product :",
print sumDot (lstA, lstB)

print "tuple dot product :",
print tupleDot (lstA, lstB)
